from app import app
from flask_mysqldb import MySQL
from flask import Flask, render_template, request, jsonify
from flask_caching import Cache

config = {
    "DEBUG": True,          # some Flask specific configs
    "CACHE_TYPE": "SimpleCache",  # Flask-Caching related configs
    "CACHE_DEFAULT_TIMEOUT": 300
}
app = Flask(__name__)
# tell Flask to use the above defined config
app.config.from_mapping(config)
cache = Cache(app)

app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'student'
app.config['MYSQL_DB'] = 'Krikey_db'

mysql = MySQL(app)

@app.route('/', methods=['GET'])
@cache.cached(timeout=500)
def app_showtables():
     cur = mysql.connection.cursor()
     cur.execute("show tables")
     rv = cur.fetchall()
     return str(rv)

@app.route('/books', methods=['GET'])
@cache.cached(timeout=500)
def app_showbooks():
     cur = mysql.connection.cursor()
     cur.execute("select * from books")
     rv = cur.fetchall()
     return str(rv)

@app.route('/authors', methods=['GET'])
@cache.cached(timeout=500)
def app_showauthors():
     cur = mysql.connection.cursor()
     cur.execute("select * from authors")
     rv = cur.fetchall()
     return str(rv)


@app.route('/sale_items', methods=['GET'])
@cache.cached(timeout=500)
def app_showsaleitems():
     cur = mysql.connection.cursor()
     cur.execute("select * from sale_items")
     rv = cur.fetchall()
     return str(rv)


@app.route('/author_name', methods=['GET'])
@cache.cached(timeout=50000)
def app_part2query3():
     name = request.args.get('name')
     if name:
         cur = mysql.connection.cursor()
         cur.execute("select q.name, sum(q.Sales_revenue) as 'Sales Revenue' from (select authors.name, sale_items.book_id,sum(sale_items.item_price * sale_items.quantity) as 'Sales_Revenue' from sale_items join books on books.id = sale_items.book_id join authors on authors.id = books.author_id group by sale_items.book_id ) q group by q.name having q.name = %s" , [name])
         rv = cur.fetchall()
         if str(rv) != '()':
            return str(rv)
         else:
             resp = jsonify('Author not found in database')
             resp.status_code = 500
             return resp
     else:
         resp = jsonify('Please use /authors?name=<value>')
         resp.status_code = 500
         return resp

if __name__ == '__main__':
    app.run(debug=True)
